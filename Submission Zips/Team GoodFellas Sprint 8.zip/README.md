# Team GoodFellas: Andrei Costin, Yifu Yang, Ethan Cairney, Jo Reilly

# Sprint 3: Story 4
#I created a nasty loop to check each pixel in the image, which will change the color of the lips to the same color as it's face, and change the color of it's extra hair to white with rgb plus 1 in random red blue or green as I can change them back as I click the button again
[Details](Screenshots/Sprint3)

# Sprint 3: Story 5&6
#I created 4 color pickers for the skin and hair colors of the two characters. When the color value of one of those color pickers changes, a method is called that redraws the character, changing each pixel of the original color to the new color.

# Sprint 4: Story 7&8
#I create a new bubble class to set a new object that need to be added in the view, I was be able to add the image of bubble with test message by using Text and Label with two if statement I was also be able to delete the message once a new text is entered.

#Changed the bubble button so that it cycles through having a speech bubble, thought bubble and no bubble. Speech is changed when button is pressed. I changed the singular text panel to two text panels, one for each character. May be a better idea to change the buttons to split menu buttons.

[Details](Screenshots/Sprint4)

# Sprint 7: Story 15&16
#When saving as an XML, a file chooser is displayed to select an existing XML file or create one. Each saved panel is looped through and XML code is written according to the panel details using PrintWriter. Using a document builder would be easier and faster so I intend to change this accordingly during the following sprint. When loading an XML file, a file chooser is displayed to allow the user to select an XML file and only XML files. When one is chosen, it does not allow invalid XML files to be parsed. Every panel is created and saved using the Java DOM parser.

# Sprint 8
Implements functionality to save html and gif. Also fixes some bugs due to the delete button. A note, there is now a permanent frame in the frame picker for "New Frame"... That is meant to add a new frame whenever required after editing a loaded frame. 
