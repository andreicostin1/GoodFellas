# Team GoodFellas: Andrei Costin, Yifu Yang, Ethan Cairney, Jo Reilly

# Sprint 3: Story 4
#I created a nasty loop to check each pixel in the image, which will change the color of the lips to the same color as it's face, and change the color of it's extra hair to white with rgb plus 1 in random red blue or green as I can change them back as I click the button again
[Details](Screenshots/Sprint3)

# Sprint 3: Story 5&6
#I created 4 color pickers for the skin and hair colors of the two characters. When the color value of one of those color pickers changes, a method is called that redraws the character, changing each pixel of the original color to the new color.
