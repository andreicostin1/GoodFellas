# Team GoodFellas: Andrei Costin, Yifu Yang, Ethan Cairney, Jo Reilly

# Sprint 3: Story 4
#I created a nasty loop to check each pixel in the image, which will change the color of the lips to the same color as it's face, and change the color of it's extra hair to white with rgb plus 1 in random red blue or green as I can change them back as I click the button again
[Details](Screenshots/Sprint3)

# Sprint 3: Story 5&6
#I created 4 color pickers for the skin and hair colors of the two characters. When the color value of one of those color pickers changes, a method is called that redraws the character, changing each pixel of the original color to the new color.

# Sprint 4: Story 7&8
#I create a new bubble class to set a new object that need to be added in the view, I was be able to add the image of bubble with test message by using Text and Label with two if statement I was also be able to delete the message once a new text is entered.

#Changed the bubble button so that it cycles through having a speech bubble, thought bubble and no bubble. Speech is changed when button is pressed. I changed the singular text panel to two text panels, one for each character. May be a better idea to change the buttons to split menu buttons.
[Details](Screenshots/Sprint4)
